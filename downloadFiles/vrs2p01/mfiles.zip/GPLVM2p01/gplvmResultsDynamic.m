function gplvmResultsDynamic(dataset, number, dataType, varargin)

% GPLVMRESULTSDYNAMIC Load a results file and visualise them.
%
% gplvmResultsDynamic(dataset, number, dataType, varargin)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.2, Tue Jul 27 11:56:08 2004
% GPLVM toolbox version 2.01


  
[model, lbls] = gplvmLoadResult(dataSet, number);

% Visualise the results
switch size(model.X, 2) 
 case 1
  gplvmVisualise1D(model, [dataType 'Visualise'], [dataType 'Modify'], ...
		   varargin{:});
  
 case 2
  gplvmVisualise(model, lbls, [dataType 'Visualise'], [dataType 'Modify'], ...
                 varargin{:});
  
 otherwise 
  error('No visualisation code for data of this latent dimension.');
end