function imageModify(handle, imageValues, imageSize, transpose, negative, ...
		     scale)

% IMAGEMODIFY Helper code for visualisation of image data.
%
% imageModify(handle, imageValues, imageSize, transpose, negative, ...
% 		     scale)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.2, Thu May  6 19:14:01 2004
% GPLVM toolbox version 2.01



if nargin < 4
  transpose = 1;
end
if nargin< 5
  negative = 0;
end
if negative
  imageValues = -imageValues;
end
if transpose
  set(handle, 'CData', reshape(imageValues, imageSize(1), imageSize(2))');
else
  set(handle, 'CData', reshape(imageValues, imageSize(1), imageSize(2)));
end
