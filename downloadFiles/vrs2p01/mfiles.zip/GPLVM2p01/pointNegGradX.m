function g = pointNegGradX(x, y, model, prior)

% POINTNEGGRADX Wrapper function for calling noise gradients.
%
% g = pointNegGradX(x, y, model, prior)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.2, Tue Jun 29 12:26:07 2004
% GPLVM toolbox version 2.01



g = ivmGradX(model, x, y);
% check if there is a prior over kernel parameters
if nargin > 3 & ~isempty(prior)
  g = g + priorGradient(prior, x);
end

g = -g;
