function [model, lbls] = gplvmLoadResult(dataSet, number)

% GPLVMLOADRESULT Load a previously saved result.
%
% [model, lbls] = gplvmLoadResult(dataSet, number)

% Copyright (c) 2004 Neil D. Lawrence
% GPLVM toolbox version 2.01



[Y, lbls] = gplvmLoadData(dataSet);

dataSet(1) = upper(dataSet(1));
load(['dem' dataSet num2str(number)])
model = ivmReconstruct(kern, noise, ivmInfo, X, Y);
