
% GPLVMPATH Brings dependent toolboxes into the path.
%
%	Description:
%	% 	gplvmPath.m CVS version 1.2
% 	gplvmPath.m SVN version 29
% 	last update 2008-01-24T09:56:50.000000Z

importTool('ivm');
