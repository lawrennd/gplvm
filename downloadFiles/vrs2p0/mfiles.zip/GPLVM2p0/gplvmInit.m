function model = gplvmInit(X, Y, kernelType, noiseType, selectionCriterion, ...
                           numActive)

% GPLVMINIT Initialise a GPLVM model.
%
% model = gplvmInit(X, Y, kernelType, noiseType, selectionCriterion, ...
%                            numActive)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.1, Wed May  5 05:13:12 2004
% GPLVM toolbox version 2.0




model = ivm(X, Y, kernelType, noiseType, selectionCriterion, numActive);
