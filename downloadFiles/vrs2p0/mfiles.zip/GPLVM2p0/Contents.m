% GPLVM toolbox
% Version 2.0 Monday, July 12, 2004 at 23:08:41
% Copyright (c) 2004 Neil D. Lawrence
% 
% ACTIVESETGRADIENT Gradient of the kernel with respect to its active points.
% CLASSVISUALISE Callback function for visualising data in 2-D.
% DEMBRENDAN1 Model the face data with a 2-D GPLVM.
% DEMBRENDAN2 Model the face data with a 1-D GPLVM.
% DEMBRENDAN3 Model the face data with a 2-D GPLVM.
% DEMDIGITS1 Model the digits data with a 2-D GPLVM.
% DEMDIGITS2 Model the digits data with a 1-D GPLVM.
% DEMDIGITS3 Model the digits data with a 2-D GPLVM.
% DEMDIGITSGTM For visualising digits data --- uses NETLAB toolbox.
% DEMDIGITSPCA Model the digits data with PCA.
% DEMHORSE1 Model the horse data with a 2-D GPLVM.
% DEMHORSE2 Model the horse data with a 2-D GPLVM.
% DEMHORSE3 Model the horse data with a 2-D GPLVM.
% DEMHORSE4 Model the horse data with a 2-D GPLVM.
% DEMHORSE1 Model the horse data with a 3-D GPLVM.
% DEMOIL1 Model the oil data with a 2-D GPLVM using RBF kernel.
% DEMOIL2 Model the oil data with a 2-D GPLVM using MLP kernel.
% DEMOIL3 Model the oil data with a 2-D GPLVM using RBF kernel and Laplacian latent prior.
% DEMOIL4 Model the oil data with a 2-D GPLVM using RBF kernel and normal uniform latent prior.
% DEMOIL4 Model the oil data with a 2-D GPLVM using RBF kernel and normal uniform latent prior.
% DEMOILGTM For visualising oil data --- uses NETLAB toolbox.
% DEMOILPCA Model the oil data with PCA.
% DEMTWOS1 Model the twos data with a 2-D GPLVM.
% DEMTWOS2 Model the twos data with a 2-D GPLVM.
% DEMTWOSGTM For visualising oil data --- uses NETLAB toolbox.
% GPLVMACTIVESETGRADIENT Wrapper function for calling gradient for active set positions.
% GPLVMACTIVESETNEGLOGLIKELIHOOD Wrapper function for calling noise likelihoods.
% GPLVMACTIVESETOBJECTIVE Wrapper function for calling noise likelihoods.
% GPLVMAPPROXLOGLIKEACTIVESETGRAD Gradient of the approximate likelihood wrt kernel parameters.
% GPLVMFANTASYPLOT Block plot of fantasy data.
% GPLVMFIT Fit a Gaussian process latent variable model.
% GPLVMGRADIENTPOINT Compute gradient of data-point likelihood wrt x.
% GPLVMINIT Initialise a GPLVM model.
% GPLVMKERNELGRADIENT Gradient of likelihood approximation wrt kernel parameters.
% GPLVMKPCAINIT Initialise gplvm model with Kernel PCA.
% GPLVMLATENTCLASSIFY Load a results file and visualise them dynamically.
% GPLVMLOADDATA Load the a dataset.
% GPLVMOPTIMISE Optimise the parameters and points of a GPLVM model.
% GPLVMOPTIMISEACTIVESET Optimise the location of the active points.
% GPLVMOPTIMISEKERNEL Jointly optimise the kernel parameters and active set positions.
% GPLVMOPTIMISEPOINT Optimise the postion of a non-active point.
% GPLVMOPTIONS Initialise an options stucture.
% GPLVMPCAINIT Initialise gplvm model with PCA.
% GPLVMRESULTSDYNAMIC Load a results file and visualise them.
% GPLVMRESULTFANTASY Load a results file and visualise the `fantasies'.
% GPLVMRESULTSSTATIC Load a results file and visualise them dynamically.
% GPLVMSCATTERPLOT 2-D scatter plot of the latent points.
% GPLVMSTATICIMAGEVISUALISE Generate a scatter plot of the images without overlap.
% GPLVMVISUALISE Visualise the manifold.
% GPLVMVISUALISE1D Visualise the fantasies along a line (as a movie).
% IMAGEMODIFY Helper code for visualisation of image data.
% IMAGEVISUALISE Helper code for showing an image during 2-D visualisation.
% POINTAPPROXNEGGRADX Wrapper function for calling approximate noise gradients.
% POINTAPPROXNEGLOGLIKELIHOOD Wrapper function for calling likelihoods.
% POINTNEGGRADX Wrapper function for calling noise gradients.
% POINTNEGLOGLIKELIHOOD Wrapper function for calling noise likelihoods.
% VECTOR3MODIFY Helper code for visualisation of 3-D vectorial data.
% VECTOR3VISUALISE  Helper code for plotting a 3-D vector during 2-D visualisation.
% VECTORMODIFY Helper code for visualisation of vectorial data.
% VECTORVISUALISE  Helper code for plotting a vector during 2-D visualisation.
