function g = activeSetGradient(model, covGrad)

% ACTIVESETGRADIENT Gradient of the kernel with respect to its active points.
%
% g = activeSetGradient(model, covGrad)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.1, Wed Jun 23 13:58:05 2004
% GPLVM toolbox version 2.0



xDim = size(model.X, 2);
g = zeros(length(model.I), xDim);
for i = 1:length(model.I)
  n = model.I(i);
  gx = kernGradX(model.kern, model.X(n, :), model.X(model.I, :));
  % The two accounts for the fact that covGrad is symmetric.
  gx = gx*2;
  % gx has assumed that n is not in model.I, fix that here.
  gx(i, :) = kernDiagGradX(model.kern, model.X(n, :));
  for j = 1:xDim
    g(i, j) = gx(:, j)'*covGrad(:, i);
  end
end
g = g(:)';