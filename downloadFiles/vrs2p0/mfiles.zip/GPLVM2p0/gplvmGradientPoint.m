function g = gplvmGradientPoint(x_i, i, model, A) %A, invK, activeX, Y, D, theta, activeSet)

% GPLVMGRADIENTPOINT Compute gradient of data-point likelihood wrt x.
%
% g = gplvmGradientPoint(x_i, i, model, A) %A, invK, activeX, Y, D, theta, activeSet)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.1, Tue Feb 17 11:35:17 2004
% GPLVM toolbox version 2.0



g = -feval([model.noiseType 'GradientPoint'], x_i, i, model, A);

