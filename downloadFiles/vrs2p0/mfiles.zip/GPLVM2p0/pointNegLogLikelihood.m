function e = pointNegLogLikelihood(x, y, model, prior)

% POINTNEGLOGLIKELIHOOD Wrapper function for calling noise likelihoods.
%
% e = pointNegLogLikelihood(x, y, model, prior)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.2, Tue Jun 29 12:25:57 2004
% GPLVM toolbox version 2.0



L = ivmLogLikelihood(model, x, y);

% check if there is a prior over kernel parameters
if nargin > 3
  L = L + priorLogProb(prior, x);
end
e = -L;
