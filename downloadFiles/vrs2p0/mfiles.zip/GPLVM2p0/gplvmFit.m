function model = gplvmFit(X, Y, numActive, options, noiseType, kernelType, lbls)

% GPLVMFIT Fit a Gaussian process latent variable model.
%
% model = gplvmFit(X, Y, numActive, options, noiseType, kernelType, lbls)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.3, Thu Jun 24 11:10:58 2004
% GPLVM toolbox version 2.0



if nargin < 7
  lbls = [];
end
selectionCriterion = 'entropy';

model = gplvmInit(X, Y, kernelType, noiseType, selectionCriterion, numActive);
model = gplvmOptimise(model, options, lbls);
