function vectorModify(handle, values)

% VECTORMODIFY Helper code for visualisation of vectorial data.
%
% vectorModify(handle, values)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.1, Thu Feb 19 14:37:27 2004
% GPLVM toolbox version 2.0



set(handle, 'YData', values);
