function g = pointApproxNegGradX(x, m, beta, model, prior)

% POINTAPPROXNEGGRADX Wrapper function for calling approximate noise gradients.
%
% g = pointApproxNegGradX(x, m, beta, model, prior)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.1, Mon Jun 21 10:56:04 2004
% GPLVM toolbox version 2.0



g = ivmApproxGradX(model, x, m, beta);

% check if there is a prior over kernel parameters
if nargin > 3
  g = g + priorGradient(prior, x(prior.index));
end

g = -g;
