function model = gplvmInit(Y, dims, options, kernelType, noiseType, selectionCriterion, numActive)

% GPLVMINIT Initialise a GPLVM model.
%
% model = gplvmInit(Y, dims, options, kernelType, noiseType, selectionCriterion, numActive)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.2, Tue Jul 20 09:45:38 2004
% GPLVM toolbox version 2.011



% Initialise X.
[X, resVariance] = gplvmInitX(Y, dims, options);

% Set up gplvm as an ivm.
model = ivm(X, Y, kernelType, noiseType, selectionCriterion, numActive);

    
  