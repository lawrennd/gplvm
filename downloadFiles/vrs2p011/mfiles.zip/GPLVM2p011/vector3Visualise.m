function handle = vector3Visualise(vals)

% VECTOR3VISUALISE  Helper code for plotting a 3-D vector during 2-D visualisation.
%
% handle = vector3Visualise(vals)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.1, Mon Jun 14 19:14:16 2004
% GPLVM toolbox version 2.011



handle = plot3(vals(:, 1), vals(:, 2), vals(:, 3), 'rx');
