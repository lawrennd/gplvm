function X = gplvmKpcaInit(Y, kern, dims)

% GPLVMKPCAINIT Initialise gplvm model with Kernel PCA.
%
% X = gplvmKpcaInit(Y, kern, dims)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.1, Fri Jun 25 11:49:40 2004
% GPLVM toolbox version 2.011


if any(any(isnan(Y)))
  error('When missing data is present Kernel PCA cannot be used to initialise')
end

K = kernCompute(kern, Y);
[u, v] = eigs(K, dims);
X = u*sqrt(v);