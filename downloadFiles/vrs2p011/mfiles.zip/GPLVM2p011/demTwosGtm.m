% DEMTWOSGTM For visualising oil data --- uses NETLAB toolbox.
%
%
% Copyright (c) 2004 Neil D. Lawrence
% File version 1.1, Thu May  6 16:15:06 2004
% GPLVM toolbox version 2.011



rand('state', 1e5);
randn('state', 1e5);


Y = gplvmLoadData('twos');

dataDim = size(Y, 2);
latentDim = 2;


latentGridDims = [15 15]; 
numLatent = prod(latentGridDims);  % Number of latent points
numCentres = 16;


% Create and initialise GTM model
model = gtm(latentDim, numLatent, dataDim, numCentres, ...
   'gaussian', 0.1);

options = foptions;
options(7) = 1;   
model = gtminit(model, options, Y, 'regular', latentGridDims, [4 4]);

options = foptions;
options(14) = 1000;
options(1) = 1;
options(3) = 1e-6;
[model, options] = gtmem(model, Y, options);

% Plot posterior means
X = gtmlmean(model, Y);
colordef white
figure, hold on
plot(X(:, 1), X(:, 2), 'rx');
