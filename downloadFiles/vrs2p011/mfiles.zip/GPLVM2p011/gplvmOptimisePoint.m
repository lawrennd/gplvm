function model = gplvmOptimisePoint(model, i, prior, display, iters);

% GPLVMOPTIMISEPOINT Optimise the postion of a non-active point.
%
% model = gplvmOptimisePoint(model, i, prior, display, iters);

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.2, Wed Jun 23 09:55:14 2004
% GPLVM toolbox version 2.011



if nargin < 5
  iters = 500;
  if nargin < 4
    display = 1;
    if nargin < 3
      prior = [];
    end
  end
end


options = foptions;
if display
  options(1) = 1;
  options(9) = 1;
end
options(14) = iters;


model.X(i, :) = scg('pointNegLogLikelihood', model.X(i, :),  options, ...
		    'pointNegGradX', model.y(i, :), model, prior);

