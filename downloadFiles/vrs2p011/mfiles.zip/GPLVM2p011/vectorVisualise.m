function handle = vectorVisualise(vals)

% VECTORVISUALISE  Helper code for plotting a vector during 2-D visualisation.
%
% handle = vectorVisualise(vals)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.2, Mon Jun 14 19:18:04 2004
% GPLVM toolbox version 2.011



handle = plot(vals);
