function e = gplvmActiveSetObjective(xVals, model, prior)

% GPLVMACTIVESETOBJECTIVE Wrapper function for calling noise likelihoods.
%
% e = gplvmActiveSetObjective(xVals, model, prior)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.1, Thu Jun 24 10:50:41 2004
% GPLVM toolbox version 2.011



model.X(model.I, :) = reshape(xVals, length(model.I), size(model.X, 2));
L = ivmApproxLogLikelihood(model);

% check if there is a prior over active set positions.
if nargin > 2 & ~isempty(prior)
  L = L + priorLogProb(prior, xVals);
end
e = -L;
