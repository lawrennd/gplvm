function e = pointApproxNegLogLikelihood(x, m, beta, model, prior)

% POINTAPPROXNEGLOGLIKELIHOOD Wrapper function for calling likelihoods.
%
% e = pointApproxNegLogLikelihood(x, m, beta, model, prior)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.1, Mon Jun 21 10:53:26 2004
% GPLVM toolbox version 2.011



L = ivmApproxLogLikelihood(model, x, m, beta);

% check if there is a prior over kernel parameters
if nargin > 3
  L = L + priorLogProb(prior, x(prior.index));
end
e = -L;
