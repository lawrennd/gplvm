function model = gplvmFit(Y, dims, options, kernelType, noiseType, ...
                          selectionCriterion, numActive, lbls)

% GPLVMFIT Fit a Gaussian process latent variable model.
%
% model = gplvmFit(Y, dims, options, kernelType, noiseType, ...
%                          selectionCriterion, numActive, lbls)
%

% Copyright (c) 2005 Neil D. Lawrence
% gplvmFit.m version 1.6



if nargin < 8
  lbls = [];
end


model = gplvmInit(Y, dims, options, kernelType, noiseType, selectionCriterion, numActive);
model = gplvmOptimise(model, options, lbls);
