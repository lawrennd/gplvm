function g = gplvmGradientPoint(x_i, i, model, A) %A, invK, activeX, Y, D, theta, activeSet)

% GPLVMGRADIENTPOINT Compute gradient of data-point likelihood wrt x.
%
% g = gplvmGradientPoint(x_i, i, model, A) %A, invK, activeX, Y, D, theta, activeSet)
%

% Copyright (c) 2005 Neil D. Lawrence
% gplvmGradientPoint.m version 1.3



g = -feval([model.noiseType 'GradientPoint'], x_i, i, model, A);

