function handle = vector3Visualise(vals)

% VECTOR3VISUALISE  Helper code for plotting a 3-D vector during 2-D visualisation.
%
% handle = vector3Visualise(vals)
%

% Copyright (c) 2005 Neil D. Lawrence
% vector3Visualise.m version 1.3



handle = plot3(vals(:, 1), vals(:, 2), vals(:, 3), 'rx');
