function [model,labels] = gplvmReadFromFile(fileName)

% GPLVMREADFROMFILE Load a file produced by the c++ implementation.
%
% [model,labels] = gplvmReadFromFile(fileName)
%

% Copyright (c) 2005 Neil D. Lawrence
% gplvmReadFromFile.m version 1.1



FID = fopen(fileName);
if FID==-1
  error(['Cannot find file ' fileName])
end
[model, labels] = gplvmReadFromFID(FID);
fclose(FID);