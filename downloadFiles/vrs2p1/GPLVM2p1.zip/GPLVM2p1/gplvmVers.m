function [vers, depend] = gplvmVers

% GPLVMVERS Brings dependent toolboxes into the path.
%
% [vers, depend] = gplvmVers
%

% Copyright (c) 2005 Neil D. Lawrence
% gplvmVers.m version 1.1



vers = 2.02;
if nargout > 2
  depend(1).name = 'ivm';
  depend(1).vers = 0.32;
  depend(1).required = 0;
end