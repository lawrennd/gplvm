function [model, lbls] = gplvmLoadResult(dataSet, number)

% GPLVMLOADRESULT Load a previously saved result.
%
% [model, lbls] = gplvmLoadResult(dataSet, number)
%

% Copyright (c) 2005 Neil D. Lawrence
% gplvmLoadResult.m version 1.2



[Y, lbls] = lvmLoadData(dataSet);

dataSet(1) = upper(dataSet(1));
load(['dem' dataSet num2str(number)])
model = ivmReconstruct(kern, noise, ivmInfo, X, Y);
