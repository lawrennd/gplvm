function X = gplvmPcaInit(Y, dims)

% GPLVMPCAINIT Initialise gplvm model with PCA.
%
% X = gplvmPcaInit(Y, dims)
%

% Copyright (c) 2005 Neil D. Lawrence
% gplvmPcaInit.m version 1.6



[X, sigma2] = ppcaEmbed(Y, dims);