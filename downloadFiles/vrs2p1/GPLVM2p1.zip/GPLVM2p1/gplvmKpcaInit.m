function X = gplvmKpcaInit(Y, kern, dims)

% GPLVMKPCAINIT Initialise gplvm model with Kernel PCA.
%
% X = gplvmKpcaInit(Y, kern, dims)
%

% Copyright (c) 2005 Neil D. Lawrence
% gplvmKpcaInit.m version 1.4



X = kpcaEmbed(Y, dims, kern);
