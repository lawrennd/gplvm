% GPLVMPATH Brings dependent toolboxes into the path.
%
% 

% Copyright (c) 2005 Neil D. Lawrence
% gplvmPath.m version 1.1



importTool('ivm');
