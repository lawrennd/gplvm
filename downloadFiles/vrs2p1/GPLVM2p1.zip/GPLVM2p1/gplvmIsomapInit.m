function [X, sigma2] = gplvmIsomapInit(Y, dims)

% GPLVMISOMAPINIT Initialise gplvm model with isomap (need isomap toolbox).
%
% [X, sigma2] = gplvmIsomapInit(Y, dims)
%

% Copyright (c) 2005 Neil D. Lawrence
% gplvmIsomapInit.m version 1.2



[X, sigma2] = isomapEmbed(Y, dims);