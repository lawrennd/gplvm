function model = gplvmInit(Y, dims, options, kernelType, noiseType, selectionCriterion, numActive)

% GPLVMINIT Initialise a GPLVM model.
%
% model = gplvmInit(Y, dims, options, kernelType, noiseType, selectionCriterion, numActive)
%

% Copyright (c) 2005 Neil D. Lawrence
% gplvmInit.m version 1.5



% Initialise X.
[X, resVariance] = gplvmInitX(Y, dims, options);

% Set up gplvm as an ivm.
model = ivm(X, Y, kernelType, noiseType, selectionCriterion, numActive);

    
  