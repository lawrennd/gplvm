function handle = vectorVisualise(vals)

% VECTORVISUALISE  Helper code for plotting a vector during 2-D visualisation.Plot the oil data

handle = plot(vals);;
