% GPLVMPATH Brings dependent toolboxes into the path.
%
%
% Copyright (c) 2005 Neil D. Lawrence
% File version 1.1, Sat Jan  1 19:51:55 2005
% GPLVM toolbox version 2.012



importTool('ivm');
