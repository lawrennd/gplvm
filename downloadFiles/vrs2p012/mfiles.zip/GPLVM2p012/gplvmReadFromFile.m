function [model,labels] = gplvmReadFromFile(fileName)

% GPLVMREADFROMFILE Load a file produced by the c++ implementation.
%
% [model,labels] = gplvmReadFromFile(fileName)

% Copyright (c) 2005 Neil D. Lawrence
% File version 1.1, Wed Jul 27 13:56:12 2005
% GPLVM toolbox version 2.012



FID = fopen(fileName);
if FID==-1
  error(['Cannot find file ' fileName])
end
[model, labels] = gplvmReadFromFID(FID);
fclose(FID);