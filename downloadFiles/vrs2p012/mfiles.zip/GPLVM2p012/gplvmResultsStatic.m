function gplvmResultsStatic(dataSet, number, dataType, varargin)

% GPLVMRESULTSSTATIC Load a results file and visualise them dynamically.
%
% gplvmResultsStatic(dataSet, number, dataType, varargin)

% Copyright (c) 2005 Neil D. Lawrence
% File version 1.5, Thu Oct 28 16:39:09 2004
% GPLVM toolbox version 2.012



[model, lbls] = gplvmLoadResult(dataSet, number);

% Visualise the results
if size(model.X, 2) ==1 
  error('not yet implemented static 1-D visualisation')

elseif size(model.X, 2) == 2
  if strcmp(dataType, 'none')
    gplvmScatterPlot(model, lbls);
  else
    gplvmStaticImageVisualise(model, [dataType 'Visualise'], 0.03, varargin{:});
  end

else
  error('no visualisation code for data of of this latent dimension');
end