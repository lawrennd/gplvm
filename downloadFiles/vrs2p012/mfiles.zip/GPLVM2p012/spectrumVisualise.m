function handle = spectrumVisualise(spectrumValues, convertFile, ...
                                    width, varargin)

% SPECTRUMVISUALISE Helper code for showing an spectrum during 2-D visualisation.
%
% handle = spectrumVisualise(spectrumValues, convertFile, ...
%                                     width, varargin)

% Copyright (c) 2005 Neil D. Lawrence
% File version 1.1, Tue Nov  9 17:50:37 2004
% GPLVM toolbox version 2.012


if nargin < 3
  width = 1000;
end
cData =zeros(length(spectrumValues), width);
if nargin > 1
c  spectrumValues = feval(convertFile, spectrumValues, varargin{:});
end
cData(1, 1) = -80;

handle = imagesc(cData);
