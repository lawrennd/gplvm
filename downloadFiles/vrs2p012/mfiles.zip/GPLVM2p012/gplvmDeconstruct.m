function [X, kern, noise, ivmInfo] = gplvmDeconstruct(model, fileName)

% GPLVMDECONSTRUCT break GPLVM in pieces for saving.
%
% [X, kern, noise, ivmInfo] = gplvmDeconstruct(model, fileName)

% Copyright (c) 2005 Neil D. Lawrence
% File version 1.1, Sat Jul 17 16:35:21 2004
% GPLVM toolbox version 2.012



X = model.X;
kern = rmfield(model.kern, 'Kstore');
kern = rmfield(kern, 'diagK');
noise = model.noise;
ivmInfo.I = model.I;
ivmInfo.J = model.J;
ivmInfo.m = model.m;
ivmInfo.beta = model.beta;

