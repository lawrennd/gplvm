% DEMOIL5 Model the oil data with probabilistic PCA.
%
%
% Copyright (c) 2005 Neil D. Lawrence
% File version 1.4, Sat Jul 17 16:38:27 2004
% GPLVM toolbox version 2.012



% Fix seeds
randn('seed', 1e5);
rand('seed', 1e5);

dataSetName = 'oil';
experimentNo = 5;

% load data
[Y, lbls] = gplvmLoadData(dataSetName);

% Model with PPCA.
X = gplvmPpcaInit(Y, 2);

capName = dataSetName;
capName(1) = upper(capName(1));
save(['dem' capName num2str(experimentNo) '.mat'], 'X');
