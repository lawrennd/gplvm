function [X, sigma2] = gplvmSppcaInit(Y, dims)

% GPLVMSPPCAINIT Initialise gplvm model with Scaled Probabilistic PCA.
%
% [X, sigma2] = gplvmSppcaInit(Y, dims)

% Copyright (c) 2005 Neil D. Lawrence
% File version 1.1, Tue Jan  4 09:02:04 2005
% GPLVM toolbox version 2.012



% Scale all Y values before doing probabilistic PCA.
for i = 1:size(Y, 2);
  va = var(Y(find(~isnan(Y(:, i))), i));
  if va ~= 0
    Y(:, i) = Y(:, i)/sqrt(va);
  end
end
[X, sigma2] = gplvmPpcaInit(Y, dims);
