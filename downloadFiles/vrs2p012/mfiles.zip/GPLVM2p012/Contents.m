% GPLVM toolbox
% Version 2.012		29-Jul-2005
% Copyright (c) 2005 Neil D. Lawrence
% 
% DEMBRENDAN1 Model the face data with a 2-D RBF GPLVM.
% DEMBRENDAN2 Model the face data with a 1-D RBF GPLVM.
% DEMBRENDAN3 Model the face data with a 2-D GPLVM.
% DEMCEPSTRAL1 Model the face data with a 2-D MLP GPLVM.
% DEMDIGITS1 Model the digits data with a 2-D RBF GPLVM.
% DEMDIGITS2 Model the digits data with a 1-D RBF GPLVM.
% DEMDIGITS3 Model the digits data with a 2-D MLP GPLVM.
% DEMDIGITSGTM For visualising digits data --- uses NETLAB toolbox.
% DEMDIGITSPCA Model the digits data with PCA.
% DEMHORSE1 Model the horse data with a 2-D Linear GPLVM.
% DEMHORSE2 Model the horse data with a 2-D RBF GPLVM.
% DEMHORSE3 Model the horse data with a 2-D MLP GPLVM.
% DEMHORSE4 Try horse classification for latent spaces from 2 dims to 8.
% DEMHORSE1 Model the horse data with a 3-D GPLVM.
% DEMHORSECLASSIFYPLOT Load results form horse classify experiments and plot them.
% DEMOIL1 Model the oil data with a 2-D GPLVM using RBF kernel.
% DEMOIL2 Model the oil data with a 2-D GPLVM using MLP kernel.
% DEMOIL3 Model the oil data with a 2-D GPLVM using RBF kernel and Laplacian latent prior.
% DEMOIL4 Model the oil data with a 2-D GPLVM using RBF kernel and normal uniform latent prior.
% DEMOIL5 Model the oil data with probabilistic PCA.
% DEMOILGTM For visualising oil data --- uses NETLAB toolbox.
% DEMOILPCA Model the oil data with PCA.
% Select a small subset of the data.
% Select a small subset of the data.
% Select a small subset of the data.
% DEMSWISSROLL1 Model the face data with a 2-D GPLVM.
% DEMSWISSROLL2 Model the face data with a 2-D GPLVM initialised with isomap.
% DEMTWOS1 Model the twos data with a 2-D RBF GPLVM with Gaussian noise.
% DEMTWOS2 Model the twos data with a 2-D RBF GPLVM with binomial noise.
% DEMTWOSGTM For visualising oil data --- uses NETLAB toolbox.
% DEMTWOSTEST Present test data to the twos models with some missing pixels.
% GPLVMACTIVESETGRADIENT Wrapper function for calling gradient for active set positions.
% GPLVMACTIVESETNEGLOGLIKELIHOOD Wrapper function for calling noise likelihoods.
% GPLVMACTIVESETOBJECTIVE Wrapper function for calling noise likelihoods.
% GPLVMAPPROXLOGLIKEACTIVESETGRAD Gradient of the approximate likelihood wrt active set.
% CLASSVISUALISE Callback function for visualising data in 2-D.
% GPLVMDECONSTRUCT break GPLVM in pieces for saving.
% GPLVMFANTASYPLOT Block plot of fantasy data.
% GPLVMFIT Fit a Gaussian process latent variable model.
% GPLVMGRADIENTPOINT Compute gradient of data-point likelihood wrt x.
% GPLVMINIT Initialise a GPLVM model.
% GPLVMINITX Initialise the X values.
% GPLVMISOMAPINIT Initialise gplvm model with isomap (need isomap toolbox).
% GPLVMKERNELGRADIENT Gradient of likelihood approximation wrt kernel parameters.
% GPLVMKPCAINIT Initialise gplvm model with Kernel PCA.
% GPLVMLATENTCLASSIFY Load a results file and classify using the latent space.
% GPLVMLOADDATA Load the a dataset.
% GPLVMLOADRESULT Load a previously saved result.
% GPLVMOPTIMISE Optimise the parameters and points of a GPLVM model.
% GPLVMOPTIMISEACTIVESET Optimise the location of the active points.
% GPLVMOPTIMISEKERNEL Jointly optimise the kernel parameters and active set positions.
% GPLVMOPTIMISEPOINT Optimise the postion of a non-active point.
% GPLVMOPTIONS Initialise an options stucture.
% GPLVMPATH Brings dependent toolboxes into the path.
% GPLVMPPCAINIT Initialise gplvm model with probabilistic PCA.
% GPLVMREADFROMFID Load from a FID produced by the c++ implementation.
% GPLVMREADFROMFILE Load a file produced by the c++ implementation.
% GPLVMRESULTSCPP Load a results file and visualise them.
% GPLVMRESULTSDYNAMIC Load a results file and visualise them.
% GPLVMRESULTFANTASY Load a results file and visualise the `fantasies'.
% GPLVMRESULTSSTATIC Load a results file and visualise them dynamically.
% GPLVMSCATTERPLOT 2-D scatter plot of the latent points.
% GPLVMSCATTERPLOT 2-D scatter plot of the latent points with color - for Swiss Roll data.
% GPLVMSPPCAINIT Initialise gplvm model with Scaled Probabilistic PCA.
% GPLVMSTATICIMAGEVISUALISE Generate a scatter plot of the images without overlap.
% GPLVMVERS Brings dependent toolboxes into the path.
% GPLVMVISUALISE Visualise the manifold.
% GPLVMVISUALISE1D Visualise the fantasies along a line (as a movie).
% IMAGEMODIFY Helper code for visualisation of image data.
% IMAGEVISUALISE Helper code for showing an image during 2-D visualisation.
% INVGETNORMAXESPOINT Take a point on a plot and return a point within the figure.
% POINTAPPROXNEGGRADX Wrapper function for calling approximate noise gradients.
% POINTAPPROXNEGLOGLIKELIHOOD Wrapper function for calling likelihoods.
% POINTNEGGRADX Wrapper function for calling noise gradients.
% POINTNEGLOGLIKELIHOOD Wrapper function for calling noise likelihoods.
% SPECTRUMMODIFY Helper code for visualisation of spectrum data.
% SPECTRUMVISUALISE Helper code for showing an spectrum during 2-D visualisation.
% GPLVMSCATTERPLOT 2-D scatter plot of the latent points with color - for Swiss Roll data.
% VECTOR3MODIFY Helper code for visualisation of 3-D vectorial data.
% VECTOR3VISUALISE  Helper code for plotting a 3-D vector during 2-D visualisation.
% VECTORMODIFY Helper code for visualisation of vectorial data.
% VECTORVISUALISE  Helper code for plotting a vector during 2-D visualisation.
