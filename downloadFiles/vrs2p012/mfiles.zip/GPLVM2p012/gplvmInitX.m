function [X, var] = gplvmInitX(Y, dims, options)

% GPLVMINITX Initialise the X values.
%
% [X, var] = gplvmInitX(Y, dims, options)

% Copyright (c) 2005 Neil D. Lawrence
% File version 1.1, Mon Sep 20 19:45:53 2004
% GPLVM toolbox version 2.012



initFunc = options.initX;
initFunc(1) = upper(initFunc(1));

[X, var] = feval(['gplvm' initFunc 'Init'], Y, dims);