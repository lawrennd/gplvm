function handle = vectorModify(handle, values)

% VECTORMODIFY Helper code for visualisation of vectorial data.
%
% handle = vectorModify(handle, values)

% Copyright (c) 2005 Neil D. Lawrence
% File version 1.4, Thu Oct 28 17:42:03 2004
% GPLVM toolbox version 2.012



set(handle, 'YData', values);
