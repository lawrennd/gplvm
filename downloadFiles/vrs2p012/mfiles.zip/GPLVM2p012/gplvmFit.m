function model = gplvmFit(Y, dims, options, kernelType, noiseType, ...
                          selectionCriterion, numActive, lbls)

% GPLVMFIT Fit a Gaussian process latent variable model.
%
% model = gplvmFit(Y, dims, options, kernelType, noiseType, ...
%                           selectionCriterion, numActive, lbls)

% Copyright (c) 2005 Neil D. Lawrence
% File version 1.6, Sat Jul 17 15:15:33 2004
% GPLVM toolbox version 2.012



if nargin < 8
  lbls = [];
end


model = gplvmInit(Y, dims, options, kernelType, noiseType, selectionCriterion, numActive);
model = gplvmOptimise(model, options, lbls);
