function vector3Modify(handle, values)

% VECTOR3MODIFY Helper code for visualisation of 3-D vectorial data.
%
% vector3Modify(handle, values)

% Copyright (c) 2005 Neil D. Lawrence
% File version 1.3, Mon Jun 14 19:34:50 2004
% GPLVM toolbox version 2.012



set(handle, 'XData', values(1));
set(handle, 'YData', values(2));
set(handle, 'ZData', values(3));

disp(values)