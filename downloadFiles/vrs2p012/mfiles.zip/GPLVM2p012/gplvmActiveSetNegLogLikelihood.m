function e = gplvmActiveSetNegLogLikelihood(xVals, y, model, prior)

% GPLVMACTIVESETNEGLOGLIKELIHOOD Wrapper function for calling noise likelihoods.
%
% e = gplvmActiveSetNegLogLikelihood(xVals, y, model, prior)

% Copyright (c) 2005 Neil D. Lawrence
% File version 1.3, Wed Jun 23 09:08:59 2004
% GPLVM toolbox version 2.012


model.X(model.I, :) = reshape(xVals, length(model.I), size(model.X, 2));
L = ivmApproxLogLikelihood(model);

% check if there is a prior over kernel parameters
if nargin > 3 & ~isempty(prior)
  for i = model.I
    L = L + priorLogProb(prior, model.X(i, prior.index));
  end
end
e = -L;
